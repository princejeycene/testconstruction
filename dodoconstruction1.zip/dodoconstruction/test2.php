<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
       
        <br><br><br><br><br><br><br>
        <center>
        <h1>Image Upload</h1>
            <form method="post" enctype="multipart/form-data">
            <table border="0"><tr>
                    <td>Building Type:<select name="option">
  <option>Residential</option>
  <option>Commercial</option>
  
</select></td>
          <tr> <td>House Name:<input type="text" name="name" /><br><br></td></tr>
           <tr><td>Front Image:<input type="file" name="img1" /><br><br></td></tr>
           <tr><td> SUb Images:<input type="file"  name="img[]" multiple="multiple"/><br><br></td></tr>
           <tr><td>Description:<textarea type="text" name="text"></textarea><br><br></td></tr>
           <tr><td> <input type="submit" name="sub"/></td></tr>
            
            </table>
            
        </form>
        </center>
        
        <?php
        $conn=mysqli_connect("localhost", "root", "", "construction");
        if(isset($_POST['sub'])){
            $option=$_POST['option'];
            if($option=='Residential'){
                    
        $name=$_POST['name'];
        $text=$_POST['text'];
        $file=$_FILES['img1']['name'];
        $tmp=$_FILES['img1']['tmp_name'];
        $filep="images/".$file;
        move_uploaded_file($tmp, $filep);
        $query="INSERT INTO `residential`(`id`, `name`,`front_img`,`text`) VALUES ('null','$name','$file','$text')";
        mysqli_query($conn, $query);
        
        $query="select * from residential where name='".$name."'";
         $result=mysqli_query($conn, $query);
        while($row=  mysqli_fetch_array($result)){
             $id= $row['id'];
         }
         for($i=0;$i<count($_FILES['img']['name']);$i++){
            $filname=$_FILES['img']['name'][$i];
            $tmpname=$_FILES['img']['tmp_name'][$i];
        
            $filepath="images/".$filname;
            move_uploaded_file($tmpname, $filepath);
            $query="INSERT INTO `independant`(`ind_id`, `img_name`, `res_id`) VALUES ('null','$filname','$id')";
            mysqli_query($conn,$query);
        }
        
        }else{
            
            $name=$_POST['name'];
        $text=$_POST['text'];
        $file=$_FILES['img1']['name'];
        $tmp=$_FILES['img1']['tmp_name'];
        $filep="images/".$file;
        move_uploaded_file($tmp, $filep);
        $query="INSERT INTO `commercial`(`id`, `name`, `front_img`, `text`) VALUES ('null','$name','$file','$text')";
        mysqli_query($conn, $query);
        
        $query="select * from commercial where name='".$name."'";
         $result=mysqli_query($conn, $query);
        while($row=  mysqli_fetch_array($result)){
             $id= $row['id'];
         }
         for($i=0;$i<count($_FILES['img']['name']);$i++){
            $filname=$_FILES['img']['name'][$i];
            $tmpname=$_FILES['img']['tmp_name'][$i];
        
            $filepath="images/".$filname;
            move_uploaded_file($tmpname, $filepath);
            $query="INSERT INTO `shop`(`shop_id`, `img_name`, `com_id`) VALUES ('null','$filname','$id')";
            mysqli_query($conn,$query);
        }
            
            
            
            
        }     
           
           
           
        }
           
              
?>
    </body>
</html>

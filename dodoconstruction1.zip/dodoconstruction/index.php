<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link href="construct.css" rel="stylesheet">
        <style>
            .l1{
               
                float: right;
                height: 230px;
                width: 50px;
                background-color: #999999;
                text-align: right;
              line-height: 25px;
            }
            
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
 
  
  cursor: pointer;
 
  border-radius: 4px;
}

#myBtn:hover {
    background-color: #e3caf2;
}
        </style>
       

    </head>
    <body>
        <!-- top banner-->
               
            
        <div class="banner">
            
         <!--       
<div class="navbar">
    <img src="img/logowithdodo.png" height="50px" width="80px;" style="margin-left: 20px;">
<a href="cart.php">CART</a>
 <a href="log.php">LOGIN</a>
<a href="contact.php">CONTACT US</a>
 <a href="pricing.php">PRICING</a>
  <a href="gallery.php">GALLERY</a>
<div class="dropdown">
    <button class="dropbtn"><a href="commercial.php">COMMERCIAL
        </a>
    </button>
    <div class="dropdown-content">
      <a href="#">SHOPS</a>
      <a href="#">MALLS</a>
      <a href="#">COMPLEX</a>
    </div>
  </div> <div class="dropdown">
      <button class="dropbtn"><a href="residential.php">RESIDENTIAL 
          </a>
    </button>
    <div class="dropdown-content">
      <a href="#">ROW HOUSES</a>
      <a href="#">OFF DUPLEX</a>
      <a href="#">FULL DUPLEX</a>
    </div>
  </div> 
  <a href="about.php">ABOUT US</a>
  <a href="index.php">HOME</a>
  
</div>-->
         <div class="navbar">
    <img src="img/logowithdodo.png" height="50px" width="80px;" style="margin-left: 20px;">
<a href="cart.php">CART</a>
 <a href="log.php">LOGIN</a>
<a href="contact.php">CONTACT US</a>
 <a href="pricing.php">PRICING</a>
  <a href="gallery.php">GALLERY</a>
<a href="commercial.php">COMMERCIAL </a>   
  <a href="residential.php">RESIDENTIAL</a>
  
  <a href="about.php">ABOUT US</a>
  <a href="index.php">HOME</a>
  
</div>
<br><br><br>
            
<div class="load">
                <div class="l1"><br>
                     <a href=""> <img src="img/fb.png" height="30x" width="30px"></a>&nbsp;&nbsp;<br>
                     <a href="">  <img src="img/gmail.jpg"height="30px" width="30px"></a>&nbsp;&nbsp;<br>
                       <a href=""> <img src="img/linkedin.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;<br>
                       <a href=""> <img src="img/instagram.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;<br>
                       
                      <a href="">  <img src="img/twitter.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
                    
                    
               
            </div></div>
        </div> 
        </br></br>
         <!-- top banner end-->
         
          <button onclick="topFunction()" id="myBtn" title="Go to top"><img src="img/up.jpg" height="60px" width="50px" ></button>
 
         
         
         
         
         <h1 style="margin-left: 5px">Residential Houses</h1><hr>
         <br>
         
         <?php
           $conn=mysqli_connect("localhost","root","","construction");
       
//$query="SELECT * FROM residential INNER JOIN independant ON residential.id=independant.res_id";

           $query="SELECT * FROM residential LIMIT 3";
           $data=  mysqli_query($conn, $query);
$total=  mysqli_num_rows($data);
if($total !=0){
 

    while ($result=  mysqli_fetch_assoc($data)){
        
            
   ?>
         <!-- houses main -->
         <div id="main">
             <div class="left">
                 <a href="new1.php?id=<?php echo $result['id'];?>"><img src="images/<?php echo $result['front_img'];?>" alt=""  height="300px" width="300px"/></a>
             </div>
             <div class="right">
                  <h3><?php echo $result['name'];?></h3>
                  <p><?php echo $result['text'];?></p>
                         
                   <a href="#" class="btn">Upload</a>
                    <a href="#" class="btn">Plan</a>
                    <a href="new1.php?id=<?php echo $result['id'];?>" class="btn">Gallery</a>
               
             </div>
         </div>
         <hr>
       
        <?php
                
    }
    
    
}
         
?> <a style="float: right;color:#f17bc3" href="residential.php">Visite More Residential Houses  </a>
         <br><br>
         <div style="margin-left: 5px">
         <h1 >Commercial Houses</h1><hr>
         <br><br><?php
           $conn=mysqli_connect("localhost","root","","construction");
       
//$query="SELECT * FROM residential INNER JOIN independant ON residential.id=independant.res_id";

           $query="SELECT * FROM commercial LIMIT 3";
           $data=  mysqli_query($conn, $query);
$total=  mysqli_num_rows($data);
if($total !=0){
 

    while ($result=  mysqli_fetch_assoc($data)){
        
            
   ?>
         <!-- houses main -->
         <div id="main1">
             <div class="left">
                 <a href="new2.php?id=<?php echo $result['id'];?>"><img src="images/<?php echo $result['front_img'];?>" alt=""  height="300px" width="300px"/></a>
             </div>
             <div class="right">
                  <h3><?php echo $result['name'];?></h3>
                  <p><?php echo $result['text'];?></p>
                         
                   <a href="#" class="btn">Upload</a>
                    <a href="#" class="btn">Plan</a>
                    <a href="new2.php?id=<?php echo $result['id'];?>" class="btn">Gallery</a>
               
             </div>
         </div>
         <hr>
       
        <?php
                
    }
    
    
}
         
         ?>
        
         <a style="float: right;color:#f17bc3" href="commercial.php">Visite More Commercial Buildings  </a>
         </div><br><br><br>
        <script>
            var nav=document.getElementById('nav');
            
            window.onscroll=function(){
                if(window.pageYOffset>100){
                nav.style.position="fixed";
                nav.style.top=0;
                }else{
                    nav.style.position="fixed";
                nav.style.top=100;
                }
            }
        </script>
        
                   <!--footer-->
                   <div class="footer">
                       <div class="footer-left">
                           </br></br><h3 style="color: white">Social Networks</h3> </br></br>
                           <a href=""> <img src="img/fb.png" height="30x" width="30px"></a>&nbsp;&nbsp;
                           <a href="">  <img src="img/gmail.jpg"height="30px" width="30px"></a>&nbsp;&nbsp;
                       <a href=""> <img src="img/linkedin.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
                       <a href=""> <img src="img/instagram.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
                   
                      <a href="">  <img src="img/twitter.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
               
                       </div><div class="footer-right">
                           </br></br><h3 style="color: white">Our Products</h3></br></br>
                           <ul>
                           <li><a href="">Dodo Water Purifier</a></li>
                           <li><a href="">Dodo Construction</a></li>
                           <li><a href="">Dodo Shoes</a></li>    </br>                       
                           <li><a href="">Dodo Pastries</a></li>      
                           </ul> 
                       </div>
                      </br></br> <h3 style="color: white">Contact Details</h3></br></br>
                       <p style="color: white">&copy; 13, Ground Floor, 1st Block, 2nd Cross, Akshya Nager, TC Palya Mian Road, Bangalore - 560016.</p>
                                    <p style="color: white">  priya@dodoconsultancyservices.com</p>
                                    <p style="color: white"> www.dodoconsultancyservices.com</p>
                                    
                                    
                   </div>
                   <script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
    </body>
</html>

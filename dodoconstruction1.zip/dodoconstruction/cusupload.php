<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body><center>
        <table bgcolor="pink" class="table-wrapper" padding="2" border="2" height="100px" width="330px"><td>
        <form method="post" enctype="multipart/form-data">
                                  
                  <input type="file" name="image"/>
                  <input type="submit" name="submit" value="upload"/> </a></td>
        </table>
    </center>
        <?php
        if(isset($_POST['submit'])){
          if(getimagesize($_FILES['image']['tmp_name'])==FALSE){
              echo"Select an Image";
          }
          else{
               $image= addslashes($_FILES['image']['tmp_name']);
               $name=  addslashes($_FILES['image']['name']);
               $image=  file_get_contents($image);
               $image=  base64_encode($image);
               saveimage($name, $image); 
               }
       }
       
       function saveimage($name,$image){
           $con=  mysql_connect("localhost","root","");
           mysql_select_db("dodo",$con);
           
           $qry="insert into fullduplx(name,image) values('$name','$image')";
           $result=  mysql_query($qry,$con);
           if($result){
               echo '<br/>Image Upload';
           }
           else{
                echo '<br/>Image not Upload';
           }
           
     }       
       ?>
        
    </body>
</html>

<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
      
    </head>
    <body>
          <form method="post" enctype="multipart/form-data">
              <input type="text" name="name" >
                  <input type="file" name="img1" id="img1">
                  <input type="file" name="img2" id="img2">
                   <input type="file" name="img3" id="img3">
                     <input type="file" name="img4" id="img4">
                       <input type="file" name="img5" id="img5">
                         <input type="file" name="img6" id="img6">
                  <input type="submit" name="submit" value="upload">
        
          </form>
        <?php
      
       $conn=mysqli_connect("localhost","root","","construction");
       
if(isset($_POST['submit'])){
$name=$_POST['name'];
$img1=$_FILES['img1']['name'];
$img2=$_FILES['img2']['name'];
$img3=$_FILES['img3']['name'];
$img4=$_FILES['img4']['name'];
$img5=$_FILES['img5']['name'];
$img6=$_FILES['img6']['name'];
$insert="insert into images values('null','$name','$img1','$img2','$img3','$img4','$img5','$img6')";
if(mysqli_query($conn,$insert)){
    
  
    move_uploaded_file($_FILES['img1']['tmp_name'], "images/$img1");
     move_uploaded_file($_FILES['img2']['tmp_name'], "images/$img2");
     move_uploaded_file($_FILES['img3']['tmp_name'], "images/$img3");
     move_uploaded_file($_FILES['img4']['tmp_name'], "images/$img4");
     move_uploaded_file($_FILES['img5']['tmp_name'], "images/$img5");
     move_uploaded_file($_FILES['img6']['tmp_name'], "images/$img6");
     echo 'Image Uploaded';
}else{
    echo 'image not uploaded';
}

}

$query="select * from images";
$data=  mysqli_query($conn, $query);
$total=  mysqli_num_rows($data);
if($total !=0){
 

    while ($result=  mysqli_fetch_assoc($data)){
        echo "
           <img src='images/".$result['img1'].
                "'height='40px' width='40px'/><img src='images/".$result['img2'].
                "'height='40px' width='40px'/><img src='images/".$result['img3'].
                "'height='40px' width='40px'/></br>
                     <img src='images/".$result['img4'].
                "'height='40px' width='40px'/><img src='images/".$result['img5'].
                "'height='40px' width='40px'/><img src='images/".$result['img6'].
                "'height='40px' width='40px'/></br>"
            
            ;
    }
    
    
}else{
    echo 'No record Found';
}

        ?>
    </body>
</html>

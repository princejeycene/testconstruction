<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Add jQuery library -->
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>

<!-- Add mousewheel plugin (this is optional) -->
<script type="text/javascript" src="fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

<!-- Add fancyBox -->
<link rel="stylesheet" href="fancybox/source/jquery.fancybox.css?v=2.1.7" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/source/jquery.fancybox.pack.js?v=2.1.7"></script>

<!-- Optionally add helpers - button, thumbnail and/or media -->
<link rel="stylesheet" href="fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
<script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

<link rel="stylesheet" href="fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
     
 <script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>
<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
<link href="construct.css" rel="stylesheet">
        <style>
            .l1{
               
                float: right;
                height: 230px;
                width: 50px;
                background-color: #999999;
                text-align: right;
              line-height: 25px;
            }
            
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
 
  
  cursor: pointer;
 
  border-radius: 4px;
}

#myBtn:hover {
    background-color: #e3caf2;
}
        </style>
       
</head>
<body>
    <button onclick="topFunction()" id="myBtn" title="Go to top"><img src="img/up.jpg" height="60px" width="50px" ></button>
    
     <div class="navbar">
    <img src="img/logowithdodo.png" height="50px" width="80px;" style="margin-left: 20px;">
<a href="cart.php">CART</a>
 <a href="log.php">LOGIN</a>
<a href="contact.php">CONTACT US</a>
 <a href="pricing.php">PRICING</a>
  <a href="gallery.php">GALLERY</a>
<a href="commercial.php">COMMERCIAL </a>   
  <a href="residential.php">RESIDENTIAL</a>
  
  <a href="about.php">ABOUT US</a>
  <a href="index.php">HOME</a>
  
</div>
    <div id="cal">
    <h1>Residential</h1><hr>   
<?php
 $conn=mysqli_connect("localhost","root","","construction");
$query="SELECT * FROM residential";
     $data=  mysqli_query($conn, $query);
$total=  mysqli_num_rows($data);
if($total !=0){
 

    while ($result=  mysqli_fetch_assoc($data)){
        
 
 
     
    ?>
         

        <a href="new11.php?id=<?php echo $result['id'];?>"><img src="images/<?php echo $result['front_img'];?>" alt=""  height="300px" width="300px"/></a>
             


     <?php       
    }}

?> 
    </div>
    <div id="cal1">
    <h1>Commercial</h1><hr>   
<?php
 $conn=mysqli_connect("localhost","root","","construction");
$query="SELECT * FROM commercial";
     $data=  mysqli_query($conn, $query);
$total=  mysqli_num_rows($data);
if($total !=0){
 

    while ($result=  mysqli_fetch_assoc($data)){
        
 
 
     
    ?>
         
<a href="new22.php?id=<?php echo $result['id'];?>"><img src="images/<?php echo $result['front_img'];?>" alt=""  height="300px" width="300px"/></a>
               


     <?php       
    }}

?> 
    </div>        
</body>
</html>
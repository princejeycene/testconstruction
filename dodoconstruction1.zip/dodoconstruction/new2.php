<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<!DOCTYPE html>
<html>
    <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Add jQuery library -->
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>

<!-- Add mousewheel plugin (this is optional) -->
<script type="text/javascript" src="fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

<!-- Add fancyBox -->
<link rel="stylesheet" href="fancybox/source/jquery.fancybox.css?v=2.1.7" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/source/jquery.fancybox.pack.js?v=2.1.7"></script>

<!-- Optionally add helpers - button, thumbnail and/or media -->
<link rel="stylesheet" href="fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
<script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

<link rel="stylesheet" href="fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
     <style>
body {
background-color: #474747;
  font-family: Verdana, sans-serif;
  margin: 0;
}

* {
  box-sizing: border-box;
}
/* The Close Button */
.close {
  color: white;
  position: absolute;
  top: 10px;
  right: 25px;
  font-size: 50px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  text-decoration: none;
  cursor: pointer;
}

#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
 
  
  cursor: pointer;
 
  border-radius: 4px;
}

#myBtn:hover {
    background-color: #e3caf2;
}

</style>
    <script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>
<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top"><img src="img/up.jpg" height="60px" width="50px" ></button>
    

    <div class="" style="margin-left: 10px;margin-right: 10px;">
  
    <?php
    
    
      $conn=mysqli_connect("localhost","root","","construction");
        $id=$_GET['id'];
          
 
    ?>

    

    
   <?php  
    $query="SELECT * FROM commercial where id='$id'";
     $data=  mysqli_query($conn, $query);
$total=  mysqli_num_rows($data);
if($total !=0){
 

    while ($result=  mysqli_fetch_assoc($data)){
   
            
    }}
    
    ?>
        
    <?php   

$query="SELECT * FROM shop where com_id='$id'";
$data=  mysqli_query($conn, $query);
$total=  mysqli_num_rows($data);
if($total !=0){
 

    while ($result=  mysqli_fetch_assoc($data)){
       
?>
    
    
        <a href="index.php#main1"><span class="close cursor" >&times;</span></a>    
       
        <a class="fancybox" rel="group" style="margin-left: 5px" href="images/<?php echo $result['img_name'];?>"><img src="images/<?php echo $result['img_name'];?>" alt="" height="300px" width="300px" /></a>
        

<?php
    }}
    ?>
    </div>
    
</body>
</html>


<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">




        <link rel="stylesheet" href="construct.css">
        <!-- Animate.css -->
        <link rel="stylesheet" href="about/css/animate.css">
        <!-- Icomoon Icon Fonts-->
        <link rel="stylesheet" href="about/css/icomoon.css">
        <!-- Bootstrap  -->
        <link rel="stylesheet" href="about/css/bootstrap.css">

        <!-- Magnific Popup -->
        <link rel="stylesheet" href="about/css/magnific-popup.css">

        <!-- Flexslider  -->
        <link rel="stylesheet" href="about/css/flexslider.css">

        <!-- Owl Carousel -->
        <link rel="stylesheet" href="about/css/owl.carousel.min.css">
        <link rel="stylesheet" href="about/css/owl.theme.default.min.css">

        <!-- Flaticons  -->
        <link rel="stylesheet" href="about/fonts/flaticon/font/flaticon.css">

        <!-- Theme style  -->
        <link rel="stylesheet" href="about/css/style.css">

        <!-- Modernizr JS -->
        <script src="about/js/modernizr-2.6.2.min.js"></script>
        <!-- FOR IE9 below -->
        <!--[if lt IE 9]>
        <script src="js/respond.min.js"></script>
        <![endif]-->

    </head>
    <body>

       
       
            <div class="navbar">
                <img src="img/logowithdodo.png" height="50px" width="80px;" style="margin-left: 20px;">
                <a href="cart.php">CART</a>
                <a href="log.php">LOGIN</a>
                <a href="contact.php">CONTACT US</a>
                <a href="pricing.php">PRICING</a>
                <a href="gallery.php">GALLERY</a>
                <a href="commercial.php">COMMERCIAL </a>   
                <a href="residential.php">RESIDENTIAL</a>

                <a href="about.php">ABOUT US</a>
                <a href="index.php">HOME</a>

            </div>
            <br><br><br>
 <div id="page">
            <div id="colorlib-about">
                <div class="container">
                    .<div class="row row-pb-lg">
                        <div class="col-md-6">
                            <div class="about animate-box">
                                <h2>Welcome to our Company</h2>

                                <h3>Our Vision</h3>
                                <p>To become the pioneer nationwide by helping the citizens of the country in terms of employment, society needs, technologies in fields such as agriculture, education, medical facilities in rural and semi-urban areas.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <img class="img-responsive" src="img/about.jpg" alt="Free HTML5 Bootstrap Template by colorlib.com">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2 text-center animate-box colorlib-heading animate-box">
                            <!--<span class="sm">Team</span>-->
                            <h2><span class="thin">Our</span> <span class="thick">Story</span></h2>
                            <p>We hail from a middle class family, studied schooling in a town and followed by college in another town. After becoming an engineering graduate, it seems ridiculously to get a job based on our studies. 
                                We need to do additional technical courses where the education curriculum doesn't support all parts of it. We need to invest our own time and money to come over to cities and spend some ampul of amount 
                                for the industrial trainings apart from the money we spend for our education. Also, getting a position in a corporate culture is a tiresome where many individuals feel as a challenge and some may not. 
                                At last they lose their family culture, heritage and their happiness. We aimed that money is needed for every individual for a purpose and it cannot rule over us. Most of the time it does, if you are 
                                committed to a larger extent based on your loans and the pay you draw. The idea strike in our minds to help the nurturing people to have good lives and a better living in their own hometowns by providing 
                                employment opportunities and several other growth similar like cities have. As a whole, this would improve our country as a developed nation. We like to stand as a pioneer leader in terms of the concept
                                of Virtualisation of Management and Businesses which would improve our economy. Here every peer member acts as his boss or become an entrepreneur instead of working for a company throughout your life.
                                We mean to say that there is no Master-Slave-Resource concept. "Dodo Consultancy Services" is named for the word Do-do which we mean as ME DO - WE DO. Its quite ridiculous to say "I" instead we use "ME".
                                We believe this is a Win-Win strategy as its a group work and group culture. Our organisation aims to promote collaboration among all the levels in the hierarchy leadership. We invite graduates, 
                                post-graduates, doctorates, businesses to join with us to have the consultation programmes which would improve and boost your values in terms of employment, improvement in business, publicity, 
                                advertising etc. Join hands with Us to become your own boss or an Entrepreneur to make your Career or Profit to a larger extent.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 text-center animate-box">
                            <div class="staff" class="staff-img" style="background-image: url(about/images/person2.jpg);">
                                <a href="#" class="desc">
                                    <h3> PRINCE JEYCENE</h3>
                                    <span>FOUNDER & CEO</span>
                                    <div class="parag">
                                        <p>Prince has worked thirteen-plus years in technology related fields and as a leader.</p>



                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <div class="staff" class="staff-img" style="background-image: url(about/images/person1.jpg);">
                                <a href="#" class="desc">
                                    <h3>PRIYA JOSEPH</h3>
                                    <span>HUMAN RESOURCE PARTNER</span>
                                    <div class="parag">
                                        <p>Include a short bio with an interesting fact about the person.</p>
                                    </div>
                                </a>
                            </div>
                        </div>


                    </div>
                </div>
            </div>

            <div id="colorlib-testimony" class="colorlib-light-grey">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 animate-box colorlib-heading animate-box">
                            <span class="sm">Testimonial</span>
                            <h2><span class="thin">What Our</span> <span class="thick">Client Says</span></h2>
                        </div>
                        <div class="col-md-7 col-md-push-1">
                            <div class="row animate-box">
                                <span class="icon"><i class="icon-quotes-left"></i></span>
                                <div class="owl-carousel1">
                                    <div class="item">
                                        <div class="testimony-slide active">
                                            <div class="testimony-wrap">
                                                <figure>
                                                    <img src="about/images/person1.jpg" alt="user">
                                                </figure>
                                                <blockquote>
                                                    <span> PRINCE JEYCENE</span>
                                                    <p>Prince has worked thirteen-plus years in technology related fields and as a leader.

                                                        Prince started his career as a Software Engineer at Palpap Ichinichi Software International Limited at Chennai.
                                                        He proved himself as a dynamic person at 
                                                        work in supporting the Quality, Development and Marketing departments to have the organisation success in implementing 
                                                        the Education ERP products for Engineering and Medical Colleges in and around Tamil Nadu. He gained the Customer 
                                                        experience at his initial phase of his career by undergoing various assignment on gathering the requirements at the
                                                        Customer site, Customising the requirements and doing gap analysis for the existing product. He is very much interested
                                                        in the Technical design during his tenure at Palpap which would make the Customer UI/UX experience at a greater extent.

                                                        Prince served for 6.5 years in First American both as a leader of technology related teams and as a subject matter
                                                        expert for their respective products.  In 2010, Prince took a position for HealthSprint Networks, with a role of 
                                                        implementing their Hospital Management System products where he eventually assumed the role as Assistant Project manager.

                                                        In 2011, Prince joined IBM, one of the IT giant to have the MNC exposure adhering to quality and its processes where he 
                                                        served as Senior Test Specialist over their IT projects.

                                                        Prince joined First American India in 2012, a title insurance company. Prince served for 6.5 years in First
                                                        American both as a leader of technology related teams and as a subject matter expert for their respective products. 
                                                        He gained the Product Management experience in terms of Product Owner, Business Analyst, Quality Assurance, Product 
                                                        Release Management, Onshore - Offshore working mode, Agility.

                                                        He is a Certified Scrum Product Owner (CSPO) from Scrum Alliance Community. He is a trained PMP professional to handle 
                                                        Projects, Programs and Portfolios.

                                                        Prince is always searching out new ideas and opportunities to enable job satisfaction in terms of humanity and building
                                                        up of our nation. He got impressed of Dr. APJ Abdul Kalam's vision to see India as a developed Country by 2020. 
                                                        He wants to fulfil his vision to see India as a developed Country in terms of Advancement in Education System Management 
                                                        upgraded with new technologies, reducing the unemployment of individuals in rural towns and urban areas. 
                                                        Helping the farmers and the agriculturalists with modernisation of agricultural techniques to survive with less amount
                                                        of water and land usage. Improving the safety among people by adopting the advanced secure and safety devices and
                                                        programs.

                                                        His ambition is to build his company nationwide across every towns and cities so that thousand and millions of people
                                                        will get benefited out of it. Prince firmly believes that his teams are his most valuable assets and that operational
                                                        stability, risk management and people engagement are only achievable through good leadership and motivation factor.</p>
                                                </blockquote>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="testimony-slide active">
                                            <div class="testimony-wrap">
                                                <figure>
                                                    <img src="about/images/person2.jpg" alt="user">
                                                </figure>
                                                <blockquote>
                                                    <span>Priya Joseph</span>
                                                    <p>Include a short bio with an interesting fact about the person.</p>
                                                </blockquote>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="testimony-slide active">
                                            <div class="testimony-wrap">
                                                <figure>
                                                    <img src="about/images/person3.jpg" alt="user">
                                                </figure>
                                                <blockquote>
                                                    <span>Adam Smith</span>
                                                    <p>Far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                                                </blockquote>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!--footer-->
            <div class="footer">
                <div class="footer-left">
                    </br></br><h3 style="color: white">Social Networks</h3> </br></br>
                    <a href=""> <img src="img/fb.png" height="30x" width="30px"></a>&nbsp;&nbsp;
                    <a href="">  <img src="img/gmail.jpg"height="30px" width="30px"></a>&nbsp;&nbsp;
                    <a href=""> <img src="img/linkedin.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
                    <a href=""> <img src="img/instagram.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;

                    <a href="">  <img src="img/twitter.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;

                </div><div class="footer-right">
                    </br></br><h3 style="color: white">Our Products</h3></br></br>
                    <ul>
                        <li><a href="">Dodo Water Purifier</a></li>
                        <li><a href="">Dodo Construction</a></li>
                        <li><a href="">Dodo Shoes</a></li>    </br>                       
                        <li><a href="">Dodo Pastries</a></li>      
                    </ul> 
                </div>
                </br></br> <h3 style="color: white">Contact Details</h3></br></br>
                <p style="color: white">&copy; 13, Ground Floor, 1st Block, 2nd Cross, Akshya Nager, TC Palya Mian Road, Bangalore - 560016.</p>
                <p style="color: white">  priya@dodoconsultancyservices.com</p>
                <p style="color: white"> www.dodoconsultancyservices.com</p>


            </div>

        </div>

        <div class="gototop js-top">
            <a href="#" class="js-gotop"><i class="icon-arrow-up2"></i></a>
        </div>

        <!-- jQuery -->
        <script src="about/js/jquery.min.js"></script>
        <!-- jQuery Easing -->
        <script src="about/js/jquery.easing.1.3.js"></script>
        <!-- Bootstrap -->
        <script src="about/js/bootstrap.min.js"></script>
        <!-- Waypoints -->
        <script src="about/js/jquery.waypoints.min.js"></script>
        <!-- Stellar Parallax -->
        <script src="about/js/jquery.stellar.min.js"></script>
        <!-- Flexslider -->
        <script src="about/js/jquery.flexslider-min.js"></script>
        <!-- Owl carousel -->
        <script src="about/js/owl.carousel.min.js"></script>
        <!-- Magnific Popup -->
        <script src="about/js/jquery.magnific-popup.min.js"></script>
        <script src="about/js/magnific-popup-options.js"></script>
        <!-- Counters -->
        <script src="about/js/jquery.countTo.js"></script>
        <!-- Main -->
        <script src="about/js/main.js"></script>

    </body>
</html>


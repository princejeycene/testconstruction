<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
   
   <link href="construct.css" rel="stylesheet">
    <!-- Font awesome -->
    <link href="assets/css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">   
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="assets/css/slick.css">          
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="assets/css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">    

    <!-- Main style sheet -->
    <link href="assets/css/style.css" rel="stylesheet">    

   
    <!-- Google Fonts -->
   

  </head>
  <body>
  
  <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>      
    </a>
  <!-- END SCROLL TOP BUTTON -->
 <div class="navbar">
    <img src="img/logowithdodo.png" height="50px" width="80px;" style="margin-left: 20px;">
<a href="cart.php">CART</a>
 <a href="log.php">LOGIN</a>
<a href="contact.php">CONTACT US</a>
 <a href="pricing.php">PRICING</a>
  <a href="gallery.php">GALLERY</a>
<a href="commercial.php">COMMERCIAL </a>   
  <a href="residential.php">RESIDENTIAL</a>
  
  <a href="about.php">ABOUT US</a>
  <a href="index.php">HOME</a>
  
</div>



 <!-- Start contact  -->
 <section id="mu-contact">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-contact-area">
          <!-- start title -->
          <div class="mu-title">
            <h2>Get in Touch</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores ut laboriosam corporis doloribus, officia, accusamus illo nam tempore totam alias!</p>
          </div>
          <!-- end title -->
          <!-- start contact content -->
          <div class="mu-contact-content">           
            <div class="row">
              <div class="col-md-6">
                <div class="mu-contact-left">
                    <h3>Contact Details</h3>
                     <p >&copy; 13, Ground Floor, 1st Block, 2nd Cross, Akshya Nager, TC Palya Mian Road, Bangalore - 560016.</p>
                                    <p>  priya@dodoconsultancyservices.com</p>
                                    <p> www.dodoconsultancyservices.com</p>
                                    <p>+91 8951496472</p>
                    
                    
                    
                    
                    
                    
                </div>
              </div>
              <div class="col-md-6">
                <div class="mu-contact-right">
                  <iframe src="Akshaya Nagar, Ramamurthy Nagar, Bengaluru, Karnataka 560016" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
              </div>
            </div>
          </div>
          <!-- end contact content -->
         </div>
       </div>
     </div>
   </div>
 </section>


 
 
 
 <!-- End contact  -->
 <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> 
 <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br><br> <br> <br> <br> <br> <br> <br>
<div class="footer">
                       <div class="footer-left">
                           </br></br><h3 style="color: white">Social Networks</h3> </br></br>
                           <a href=""> <img src="img/fb.png" height="30x" width="30px"></a>&nbsp;&nbsp;
                           <a href="">  <img src="img/gmail.jpg"height="30px" width="30px"></a>&nbsp;&nbsp;
                       <a href=""> <img src="img/linkedin.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
                       <a href=""> <img src="img/instagram.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
                   
                      <a href="">  <img src="img/twitter.jpg" height="30px" width="30px"></a>&nbsp;&nbsp;
               
                       </div><div class="footer-right">
                           </br></br><h3 style="color: white">Our Products</h3></br></br>
                           <ul>
                           <li><a href="">Dodo Water Purifier</a></li>
                           <li><a href="">Dodo Construction</a></li>
                           <li><a href="">Dodo Shoes</a></li>    </br>                       
                           <li><a href="">Dodo Pastries</a></li>      
                           </ul> 
                       </div>
                      </br></br> <h3 style="color: white">Contact Details</h3></br></br>
                       <p style="color: white">&copy; 13, Ground Floor, 1st Block, 2nd Cross, Akshya Nager, TC Palya Mian Road, Bangalore - 560016.</p>
                                    <p style="color: white">  priya@dodoconsultancyservices.com</p>
                                    <p style="color: white"> www.dodoconsultancyservices.com</p>
                                    <p style="color: white">+91 8951496472</p>
                                    
                   </div>
  


  
  <!-- jQuery library -->
  <script src="assets/js/jquery.min.js"></script>  
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="assets/js/bootstrap.js"></script>   
  <!-- Slick slider -->
  <script type="text/javascript" src="assets/js/slick.js"></script>
  <!-- Counter -->
  <script type="text/javascript" src="assets/js/waypoints.js"></script>
  <script type="text/javascript" src="assets/js/jquery.counterup.js"></script>  
  <!-- Mixit slider -->
  <script type="text/javascript" src="assets/js/jquery.mixitup.js"></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src="assets/js/jquery.fancybox.pack.js"></script>

  <!-- Custom js -->
  <script src="assets/js/custom.js"></script> 

  </body>
</html>